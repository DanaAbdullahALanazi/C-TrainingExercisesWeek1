﻿using System;


public class Ex3
{
    public static void Main(string[] args)
    {
        int[] integers = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
        double avg = FindAvg(integers);
        int min = FindMin(integers);
        int max = FindMax(integers);
        int count = CountEven(integers);
        Console.WriteLine($"The avarage={avg}, The minimum={min}, The maximum={max}, The number of even numbers={count}");
    }//end main

    public static double FindAvg(int[] array)
    {
        int avg = 0;
        foreach (int i in array)
        {
            avg += i;
        }
        return avg / array.Length;
    }//end findAvg

    public static int FindMin(int[] array)
    {
        int min = array[0];
        for (int i = 1; i < array.Length; i++)
        {
            if (array[i] < min)
            {
                min = array[i];
            }
        }
        return min;
    }//end findMin

    public static int FindMax(int[] array)
    {
        int max = array[0];
        for (int i = 1; i < array.Length; i++)
        {
            if (array[i] > max)
            {
                max = array[i];
            }
        }
        return max;
    }//end findMax

    public static int CountEven(int[] array)
    {
        int count = 0;
        for (int i = 0; i < array.Length; i++)
        {
            if (array[i] % 2 == 0)
            {
                count++;
            }
        }
        return count;
    }//end countEven

}//end class