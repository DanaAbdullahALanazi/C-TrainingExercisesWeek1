﻿using System;


public class Ex4
{
    public static void Main(string[] args)
    {
        Random random = new Random();
        int theNumber = random.Next(1, 101); //NOTE: I had to look up the random number generation from copilot but the rest is all me.
        int attempts = 0;
        Console.WriteLine("Hello and welcome to the Number Guessing Game!\n Enter a number from 1 to 100 if you get it right you win, if not keep trying till you get it! Ready? GO!");
        Console.Write("Your guess: ");
        int userGuess = Convert.ToInt32(Console.ReadLine());
        attempts++;
        while (userGuess != theNumber)
        {
            if (userGuess > theNumber)
            {
                Console.WriteLine("\nToo high");
            }
            else
            {
                Console.WriteLine("\nToo low");
            }
            Console.Write("Your guess: ");
            userGuess = Convert.ToInt32(Console.ReadLine());
            attempts++;
        }
        Console.WriteLine($"\nCongrats you won after {attempts} attempt/s ! you are such a genius!");
    }//end main


}//end class