using System;

public class Ex1
{
    public static void Main(string[] args)
    {
        double[] grades = new double[5];
        Console.WriteLine("Hello and welcome to the Grade Calculator please enter 5 marks:");
        for (int i = 0; i <= 4; i++)
        {
            double userInput = Convert.ToDouble(Console.ReadLine());
            grades[i] = userInput;
        }
        double avg = CalcAvg(grades);
        Console.WriteLine($"The grade is: {CalcGrade(grades)}");
    }//end main

    public static char CalcGrade(double[] grades)
    {
        double avg = CalcAvg(grades);
        if (avg >= 90)
        {
            return 'A';
        }
        if (avg >= 80)
        {
            return 'B';
        }
        if (avg >= 70)
        {
            return 'C';
        }
        if (avg >= 60)
        {
            return 'D';
        }
        return 'F';
    }//end calcGrade

    public static double CalcAvg(double[] grades)
    {
        double avg = 0;
        foreach (double d in grades)
        {
            avg += d;
        }
        return avg / grades.Length;
    }//end CalcAvg
}//end class