﻿using System;


public class Ex2
{
    public static void Main(string[] args)
    {
        Console.WriteLine("Hello and welcome to the Prime Number Finder program!");
        Console.WriteLine("Printing all prime numbers from 1 to 100:");
        int number = 1;
        while (number <= 100)
        {
            if (number == 1)
            {
                number++;
                continue;
            }

            else if (IsPrime(number))
            {
                Console.WriteLine(number);
            }
            number++;
        }
    }//end main

    public static bool IsPrime(int number)
    {
        bool isPrime = true;
        for (int i = 2; i <= Math.Sqrt(number); i++)//NOTE: I had to use copilot assistant to look up the Sqrt() method but the rest is all me.
        {
            if (number % i == 0 && i != number)
            {
                isPrime = false;
                return false;
            }
        }
        return isPrime;
    }
}//end class