using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;

public class AppDBContext : IdentityDbContext<IdentityUser>
{
    public DbSet<Blogs> Blogs { get; set; }

    public AppDBContext(DbContextOptions Options) : base(Options)
    {

    }
}//end class