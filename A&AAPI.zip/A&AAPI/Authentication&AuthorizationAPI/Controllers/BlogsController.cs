using System;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
//refrence all the neccessary packages

/*"api/[controller]" gets replaced at runtime with the name 
of your controller class minus the Controller suffix.*/
[Route("api/[controller]")]
/*This attribute turns your class into a modern 
Web API controller with built-in conveniences:*/
[ApiController]
/*This is the gatekeeper — it restricts access to authorized users only.*/
[Authorize]

public class BlogsController : ControllerBase
{
    private readonly AppDBContext context; //Context is our access point to our database 

    public BlogsController(AppDBContext context)
    {
        this.context = context;
    }

    [HttpGet]//Get: api/Blogs returns all blogs records
    public async Task<ActionResult<IEnumerable<Blogs>>> GetAllBlogs()
    {
        return await context.Blogs.ToListAsync();
    }

    [HttpGet("{Id}")]//Get: api/Blogs/id returns the blog with the exact user provided id
    public async Task<ActionResult<Blogs>> GetBlogById(int Id)
    {
        Blogs? targetBlog = await context.Blogs.FindAsync(Id);
        if (targetBlog == null)
        {
            return NotFound();
        }
        return Ok(targetBlog);
    }

    [HttpPut("{Id}")]//PUT: updates the blog with the exact user provided id
    public async Task<IActionResult> UpdateBlogs(int Id, Blogs blog)
    {
        if (Id != blog.BlogId)
        {
            return BadRequest();
        }
        Blogs? targetBlog = await context.Blogs.FindAsync();
        if (targetBlog == null)
        {
            return NotFound();
        }
        targetBlog.BlogTitle = blog.BlogTitle;
        targetBlog.BlogDescription = blog.BlogDescription;
        targetBlog.BlogAuthor = blog.BlogAuthor;
        try
        {
            await context.SaveChangesAsync();
            return NoContent();
        }
        catch (DbUpdateConcurrencyException)
        {
            return StatusCode(409, "Concurrency conflict occurred.");
        }
    }

    [HttpPost]//POST: api/Blogs adds a new Blog to the database
    public async Task<ActionResult<Blogs>> AddBlog(Blogs newBlog)
    {
        await context.Blogs.AddAsync(newBlog);
        await context.SaveChangesAsync();
        /*gives the client both confirmation of creation 
        and a way to fetch the newly created item*/
        return CreatedAtAction("GetBlogById", new { Id = newBlog.BlogId }, newBlog);//best practice in REST APIs
    }

    [HttpDelete("{Id}")]
    public async Task<ActionResult<Blogs>> DeleteBlogById(int Id)
    {
        Blogs? targetBlog = await context.Blogs.FindAsync(Id);
        if (targetBlog == null)
        {
            return NotFound();
        }
        context.Blogs.Remove(targetBlog);
        return NoContent();
    }


}//end class



