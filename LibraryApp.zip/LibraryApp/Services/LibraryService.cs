using System;
using System.Data.Common;
public class LibraryService
{

    private List<Book> Books = new List<Book>();

    public List<Book> books
    {
        set
        {
            Books = value;
        }

        get
        {
            return Books;
        }
    }

    public void AddBook(Book book)
    {
        Books.Add(book);
        Console.WriteLine("Book is added successfully!");
    }//end AddBook

    public void ListBooks()
    {
        foreach (Book book in Books)
        {
            Console.Write($"Book's Id: {book.id}, Book's Title: {book.title}, Book's Author: {book.author}, Year of publish: {book.yearPublished}\n");
        }
    }//end ListBooks

}//end class
