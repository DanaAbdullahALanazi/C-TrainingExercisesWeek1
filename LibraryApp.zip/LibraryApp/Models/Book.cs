using System;
using System.Data.Common;
public class Book
{

    private int Id;
    private string? Title;
    private string? Author;
    private int YearPublished;

    public int id
    {
        set
        {
            Id = value;
        }

        get
        {
            return Id;
        }
    }

    public string author
    {
        set
        {
            Author = value;
        }

        get
        {
            return Author ?? string.Empty;
        }
    }

    public string title
    {
        set
        {
            Title = value;
        }

        get
        {
            return Title ?? string.Empty;
        }
    }

    public int yearPublished
    {
        set
        {
            YearPublished = value;
        }

        get
        {
            return YearPublished;
        }
    }
}//end class