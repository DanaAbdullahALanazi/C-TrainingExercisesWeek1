﻿using System;
using System.Data.Common;
public class Program
{

    public static void Main(string[] args)
    {
        LibraryService LS = new LibraryService();
        Book fakeBook = new Book();
        fakeBook.id = 0;
        fakeBook.title = "Master C# in no time!";
        fakeBook.author = "Mohannad AlMaqableh";
        fakeBook.yearPublished = 2025;
        if (InputValidator.IsValidYear(fakeBook.yearPublished))
        {
            LS.AddBook(fakeBook);
        }
        else Console.WriteLine("Year of publish is invalid!");
        LS.ListBooks();
    }//end main


}//end class
