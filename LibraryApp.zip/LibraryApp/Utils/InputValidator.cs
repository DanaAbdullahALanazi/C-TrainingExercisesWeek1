using System;
using System.Data.Common;
public class InputValidator
{

    public static bool IsValidYear(int year)
    {
        if (year > 1900 || year <= DateTime.Now.Year)
        {
            return true;
        }
        else return false;

    }//end IsValidYeara


}//end class
