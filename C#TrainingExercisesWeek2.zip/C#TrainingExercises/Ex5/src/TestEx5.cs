﻿using System;


public class TestEx5
{
    public static void Main(string[] args)
    {
        BankAccount userAcc = new BankAccount();
        userAcc.SetBalance(50000f);
        Console.Write("Welcome back! what would like to do? \n1) Deposit\n2) Withdraw\n3) Check balance\nEnter 1, 2, or 3 and -1 to stop:");
        int userChoise = Convert.ToInt32(Console.ReadLine());
        while (userChoise != -1)
        {
            switch (userChoise)
            {
                case 1:
                    Console.Write("Enter the amount you want to deposit:");
                    float depositAmount = float.Parse(Console.ReadLine());
                    userAcc.Deposit(depositAmount);
                    break;
                case 2:
                    Console.Write("Enter the amount you want to withdraw:");
                    float withdrawAmount = float.Parse(Console.ReadLine());
                    userAcc.Withdraw(withdrawAmount);
                    break;
                case 3:
                    Console.WriteLine($"Current balance: {userAcc.GetBalance()} SR");
                    break;
                default:
                    Console.WriteLine("Invalid choise please try again!");
                    break;
            }
            Console.Write("what would like to do? \n1) Deposit\n2) Withdraw\n3) Check balance\nEnter 1, 2, or 3 and -1 to stop:");
            userChoise = Convert.ToInt32(Console.ReadLine());
        }
        Console.WriteLine("Thank you and goodbye!");
    }//end main


}//end class