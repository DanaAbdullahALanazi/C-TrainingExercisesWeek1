using System;

public class BankAccount
{
    protected float balance;

    public void SetBalance(float balance)
    {
        this.balance = balance;
    }//end setter
    public void Deposit(float amount)
    {
        while (amount <= 0)
        {
            Console.Write("The amount you entered is invalid! please try agian.\nAmount: ");
            amount = float.Parse(Console.ReadLine());
        }
        balance += amount;
        Console.WriteLine($"{amount} is successfully deposited into your account! ");
    }//end Deposit

    public void Withdraw(float amount)
    {
        while (amount <= 0 || amount > balance)
        {
            Console.Write("The amount you entered is invalid! please try agian.\nAmount: ");
            amount = float.Parse(Console.ReadLine());
        }
        balance -= amount;
        Console.WriteLine($"{amount} is successfully withdrawn from your account! ");
    }//end withdraw

    public float GetBalance()
    {
        return balance;
    }//end getBalance




}//end class