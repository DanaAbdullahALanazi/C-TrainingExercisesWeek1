using System;
public class User
{
    private string name;
    private List<Book> borrowedBooks;
    public void DisplayBorrowedBooks()
    {
        foreach (Book book in borrowedBooks)
        {
            Console.WriteLine($"Book title: {book.title} Book author: {book.author} Book ISBN: {book.ISBN}");
        }
    }//end displayBorrowedBooks


}//end class
