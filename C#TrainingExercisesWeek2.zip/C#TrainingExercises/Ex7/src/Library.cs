using System;
public class Library
{
    private List<Book> books;

    public void AddBook(Book book)
    {
        books.Add(book);
        Console.WriteLine("Book is added successfully!");
    }//end addBook

    public bool SearchByTitle(string title)
    {
        bool isFound = false;
        foreach (Book b in books)
        {
            if (title == book.title)
            {
                isFound = true;
                break;
            }
        }
        return isFound;
    }//end searchBook

    public void BorrowBook(User user, Book book)
    {
        if (SearchBook(book))
        {
            Books.Remove(book);
            user.BorrowedBooks.Add(book);
            Console.WriteLine($"{user.name} borrowed '{book.title}'.");
        }
        else Console.WriteLine($"This book unavailable.");
    }

    public void ReturnBook(User user, Book book)
    {
        if (user.borrowedBooks.Contains(book))
        {
            user.BorrowedBooks.Remove(book);
            Books.AddBook(book);
            Console.WriteLine($"{user.name} returned '{book.title}'.");
        }
    }


}//end class
