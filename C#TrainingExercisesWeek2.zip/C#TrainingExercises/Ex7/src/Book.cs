using System;
public class Book
{
    private string title;
    private string author;
    private string ISBN;

}//end class