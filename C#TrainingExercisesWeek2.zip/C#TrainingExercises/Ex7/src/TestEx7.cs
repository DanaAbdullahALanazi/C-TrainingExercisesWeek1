﻿public class TestEx7
{
    static void Main()
    {
        // Create library and users
        Library library = new Library();
        User user1 = new User { name = "Alice" };
        User user2 = new User { name = "Bob" };

        // Add books to library
        Book book1 = new Book { title = "1984", author = "George Orwell", ISBN = "9780451524935" };
        Book book2 = new Book { title = "The Hobbit", author = "J.R.R. Tolkien", ISBN = "9780261103344" };
        Book book3 = new Book { title = "Dune", author = "Frank Herbert", ISBN = "9780441013593" };
        Book book4 = new Book { title = "Clean Code", author = "Robert C. Martin", ISBN = "9780132350884" };

        library.AddBook(book1);
        library.AddBook(book2);
        library.AddBook(book3);
        library.AddBook(book4);

        // Search for a book
        Console.WriteLine("\nSearching for 'Dune':");
        bool isBookFound = library.SearchByTitle("Dune");
        Console.WriteLine($"Book is found.");

        // Borrowing books
        library.BorrowBook(user1, book3); // Alice borrows "Dune"
        library.BorrowBook(user2, book2); // Bob borrows "The Hobbit"
        library.BorrowBook(user1, book1); // Alice borrows "1984"

        // Display borrowed books
        library.DisplayBorrowedBooks(user1);
        library.DisplayBorrowedBooks(user2);

        // Return a book
        library.ReturnBook(user1, book3); // Alice returns "Dune"

        // Check library inventory after return
        library.DisplayBorrowedBooks(user1);

        // Try to borrow a non-existing book
        var fakeBook = new Book { Title = "Ghost Book" };
        library.BorrowBook(user2, fakeBook);
    }
}//end class