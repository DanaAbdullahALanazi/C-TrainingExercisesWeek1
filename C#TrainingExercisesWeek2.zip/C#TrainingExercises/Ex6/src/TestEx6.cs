﻿using System;

public class TestEx6
{
    public static void Main(string[] args)
    {
        Shape[] shapes = new Shape[3];
        Circle circle = new Circle();
        circle.SetRadius(10);
        Triangle triangle = new Triangle();
        triangle.SetBase(4);
        triangle.SetHeight(8);
        Rectangle rectangle = new Rectangle();
        rectangle.SetHeight(6);
        rectangle.SetWidth(2);
        shapes[0] = circle;
        shapes[1] = triangle;
        shapes[2] = rectangle;
        foreach (Shape s in shapes)
        {
            Console.WriteLine($"Area= {s.Area()}");
        }
    }//end main

}//end class