using System;
public class Triangle : Shape
{
    private double Base;
    private double Height;

    public void SetBase(double Base)
    {
        this.Base = Base;
    }//end setter

    public void SetHeight(double Height)
    {
        this.Height = Height;
    }//end setter
    public override double Area()
    {
        return 0.5 * Base * Height;
    }//end area

}//end class