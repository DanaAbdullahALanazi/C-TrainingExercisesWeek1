using System;
public class Rectangle : Shape
{
    private double Height;
    private double Width;

    public void SetWidth(double Width)
    {
        this.Width = Width;
    }//end setter

    public void SetHeight(double Height)
    {
        this.Height = Height;
    }//end setter
    public override double Area()
    {
        return Height * Width;
    }//end area

}//end class