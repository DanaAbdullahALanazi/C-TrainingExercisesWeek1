using System;
public class Circle : Shape
{
    private double Radius;

    public void SetRadius(double Radius)
    {
        this.Radius = Radius;
    }//end setter

    public override double Area()
    {
        return Math.PI * Math.Pow(Radius, 2);
    }//end area

}//end class