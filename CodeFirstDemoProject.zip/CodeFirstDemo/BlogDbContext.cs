using System;
using Microsoft.EntityFrameworkCore;
public class BlogDbContext : DbContext
{
    public DbSet<Post> Posts { get; set; }
    public DbSet<User> Users { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        optionsBuilder.UseSqlServer("Server=localhost;Database=CodeFirstDemo;Trusted_Connection=True;TrustServerCertificate=True;");
    }//end 
}//end 


