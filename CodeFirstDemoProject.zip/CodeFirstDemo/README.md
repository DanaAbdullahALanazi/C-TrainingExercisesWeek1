# CodeFirstDemo

This is a simple console application that demonstrates how to connect to a SQL Server database using Entity Framework Core with a Code First approach.

## Project Structure

- **Program.cs**: Entry point of the application that initializes the DbContext and tests database connectivity.
- **GovEmployeeDbContext.cs**: Defines the DbContext class with DbSet properties for Employee and Ministry entities.
- **Employee.cs**: Represents the Employee entity with properties such as Id, Name, and Position.
- **Ministry.cs**: Represents the Ministry entity with properties such as Id and Name.
- **appsettings.json**: Contains configuration settings, including logging and the database connection string.

## Getting Started

1. **Clone the repository** or download the project files.
2. **Open the project** in your preferred IDE or text editor.
3. **Restore the NuGet packages** required for Entity Framework Core.
4. **Update the connection string** in `appsettings.json` if necessary to match your database configuration.
5. **Run the application** using the command line or your IDE.

## Running the Application

To run the application, use the following command in the terminal:

```
dotnet run
```

This will execute the `Main` method in `Program.cs`, which will attempt to connect to the database and output the result to the console.