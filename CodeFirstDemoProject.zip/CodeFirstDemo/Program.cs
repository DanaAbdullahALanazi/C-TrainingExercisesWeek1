﻿
public class Program
{
    public static void Main(string[] args)
    {
        using var context = new BlogDbContext();//Here we create the database context AKA the bridge between .Net and SQL 
        context.Database.EnsureCreated();//Here we build the actual database same as CREATE DATABASE(...); 
        Console.WriteLine("Hello! and welcome to the full CRUD Blog system in \"Code First Approach\":");
        Console.Write("1) List all Users \n2) List all posts \n3) Create new account \n4) Add new Post \n5) Edit account details  \n6) Edit Post \n7) Delete Post \n8) Delete account \n9) Search account by filter \n10) Search Post by filter\nEnter the number of the option you want OR enter -1 to stop: ");
        int choise = Int32.Parse(Console.ReadLine());
        while (choise != -1)
        {
            switch (choise)
            {
                case 1:
                    var usersList = context.Users.ToList();//Here we are accessing the property Users and then calling ToList() for listing the tuples.
                    if (usersList.Any())
                    {
                        Console.WriteLine($"-----------------------------------------------------------");
                        foreach (var user1 in usersList)
                        {
                            Console.WriteLine($"Account ID: {user1.Id}\nAccount Name: {user1.Name}\nUsername: {user1.Username}\nAccount Region:{user1.Region}");
                            Console.WriteLine($"-----------------------------------------------------------");
                        }
                    }
                    else Console.WriteLine("No results found!");

                    break;
                case 2:
                    var postsList = context.Posts.ToList();//Here we are accessing the property Users and then calling ToList() for listing the tuples.
                    if (postsList.Any())
                    {
                        Console.WriteLine($"-----------------------------------------------------------");
                        foreach (var post1 in postsList)
                        {
                            Console.WriteLine($"Post ID: {post1.Id}\nDate published: {post1.DatePublished}\nTitle: {post1.Title}\nContent:{post1.Body}");
                            Console.WriteLine($"-----------------------------------------------------------");
                        }
                    }
                    else Console.WriteLine("No results found!");
                    break;
                case 3:
                    Console.Write("Enter Name: ");
                    string name = Console.ReadLine();
                    Console.Write("Enter Username: ");
                    string username = Console.ReadLine();
                    Console.Write("Enter Region: ");
                    string region = Console.ReadLine();
                    var user = new User { Name = name, Username = username, Region = region };
                    context.Users.Add(user);
                    context.SaveChanges();
                    Console.WriteLine("New account added successfully!");
                    break;
                case 4:
                    Console.Write("Enter Title: ");
                    string title = Console.ReadLine();
                    Console.Write("Enter Content: ");
                    string body = Console.ReadLine();
                    DateTime now = DateTime.Now;
                    var post = new Post { DatePublished = now, Title = title, Body = body };
                    context.Posts.Add(post);
                    context.SaveChanges();
                    Console.WriteLine("New post added successfully!");
                    break;
                case 5:
                    Console.Write("Enter the username of the account you want to edit: ");
                    string targetUsername = Console.ReadLine();
                    var targetAccount = context.Users.FirstOrDefault(a => a.Username == targetUsername);// Step 1: Retrieve the tuple by Username
                    if (targetAccount != null)
                    { //in case an account is found
                        Console.Write("What would you like to change?  1) Name 2) Username 3) Region\n choose 1,2,3 OR -1 to cancel: ");
                        int userEditChoise = Convert.ToInt32(Console.ReadLine());
                        if (userEditChoise != -1)
                        {
                            switch (userEditChoise)
                            {
                                case 1:
                                    Console.Write("Enter the new Name: ");
                                    string newName = Console.ReadLine();
                                    targetAccount.Name = newName;
                                    context.SaveChanges();
                                    break;
                                case 2:
                                    Console.Write("Enter the new Username: ");
                                    string newUsername = Console.ReadLine();
                                    targetAccount.Username = newUsername;
                                    context.SaveChanges();
                                    break;
                                case 3:
                                    Console.Write("Enter the new Region: ");
                                    string newRegion = Console.ReadLine();
                                    targetAccount.Region = newRegion;
                                    context.SaveChanges();
                                    break;
                                default:
                                    Console.WriteLine("The choice you entered is incorrect!");
                                    break;
                            }
                        }
                    }
                    else Console.WriteLine("Account not found.");
                    break;
                case 6:
                    Console.Write("Enter the title of the post you want to edit: ");
                    string targetTitle = Console.ReadLine();
                    var targetPost = context.Posts.FirstOrDefault(p => p.Title == targetTitle);// Step 1: Retrieve the tuple by Username
                    if (targetPost != null)
                    { //in case an account is found
                        Console.Write("What would you like to change?  1) Title 2) Content\n choose 1,2, OR -1 to cancel: ");
                        int postEditChoise = Int32.Parse(Console.ReadLine());
                        if (postEditChoise != -1)
                        {
                            switch (postEditChoise)
                            {
                                case 1:
                                    Console.Write("Enter the new Title: ");
                                    string newTitle = Console.ReadLine();
                                    targetPost.Title = newTitle;
                                    context.SaveChanges();
                                    break;
                                case 2:
                                    Console.Write("Enter the new content: ");
                                    string newContent = Console.ReadLine();
                                    targetPost.Body = newContent;
                                    context.SaveChanges();
                                    break;
                                default:
                                    Console.WriteLine("The choice you entered is incorrect!");
                                    break;
                            }
                        }

                    }
                    else Console.WriteLine("Post not found.");
                    break;
                case 7:
                    List<Post> currentPosts = context.Posts.ToList();
                    if (currentPosts.Any())
                    {
                        Console.WriteLine("These are your current posts:");
                        for (int i = 1; i <= currentPosts.Count; i++)
                        {
                            Console.WriteLine($"{i}) {currentPosts[i - 1].Title}: {currentPosts[i - 1].Body}");
                        }
                        Console.Write($"Enter the number of the post you want to delete OR -1 to cancel:");
                        int deletePostChoise = Convert.ToInt32(Console.ReadLine());
                        if (deletePostChoise != -1)
                        {
                            Post postToDelete = currentPosts[deletePostChoise - 1];
                            context.Posts.Remove(postToDelete);
                            context.SaveChanges();
                            Console.WriteLine("Post deleted successfully!");
                        }
                        else break;
                    }
                    else Console.WriteLine("No results found!");
                    break;
                case 8:
                    List<User> currentUsers = context.Users.ToList();
                    if (currentUsers.Any())
                    {
                        Console.WriteLine("These are the current users:");
                        for (int i = 1; i <= currentUsers.Count; i++)
                        {
                            Console.WriteLine($"{i}) {currentUsers[i - 1].Username}: {currentUsers[i - 1].Region}");
                        }
                        Console.Write($"Enter the number of the account you want to delete OR -1 to cancel:");
                        int deleteUserChoise = Convert.ToInt32(Console.ReadLine());
                        if (deleteUserChoise != -1)
                        {
                            User userToDelete = currentUsers[deleteUserChoise - 1];
                            context.Users.Remove(userToDelete);
                            context.SaveChanges();
                            Console.WriteLine("Account deleted successfully!");
                        }
                        else break;
                    }
                    else Console.WriteLine("No results found!");
                    break;
                case 9:
                    Console.Write("What would you like to search by?  1) Name 2) Region\n choose 1,2 OR -1 to cancel: ");
                    int userFilterChoise = Convert.ToInt32(Console.ReadLine());
                    if (userFilterChoise != -1)
                    {
                        switch (userFilterChoise)
                        {
                            case 1:
                                Console.Write("Enter the Name you want to search by: ");
                                string searchByName = Console.ReadLine();
                                var nameResult = context.Users.Where(u => u.Name == searchByName);
                                if (nameResult.Any())
                                {
                                    foreach (var user2 in nameResult)
                                    {
                                        Console.WriteLine($"Account ID: {user2.Id}\nAccount Name: {user2.Name}\nUsername: {user2.Username}\nAccount Region:{user2.Region}");
                                    }
                                }
                                else Console.WriteLine("No results found!");
                                break;
                            case 2:
                                Console.Write("Enter the Region you want to search by: ");
                                string searchByRegion = Console.ReadLine();
                                var regionResult = context.Users.Where(u => u.Region == searchByRegion);
                                if (regionResult.Any())
                                {
                                    foreach (var user2 in regionResult)
                                    {
                                        Console.WriteLine($"Account ID: {user2.Id}\nAccount Name: {user2.Name}\nUsername: {user2.Username}\nAccount Region:{user2.Region}");
                                    }
                                }
                                else Console.WriteLine("No results found!");
                                break;
                            default:
                                Console.WriteLine("The choice you entered is incorrect!");
                                break;
                        }
                    }
                    break;
                case 10:
                    Console.Write("What would you like to search by?  1) Publish Date 2) Title\n choose 1,2 OR -1 to cancel: ");
                    int postFilterChoise = Convert.ToInt32(Console.ReadLine());
                    if (postFilterChoise != -1)
                    {
                        switch (postFilterChoise)
                        {
                            case 1:
                                Console.Write("Enter the Date you want to search by (e.g., 7/7/2025): ");
                                string userDateinput = Console.ReadLine();

                                try
                                {
                                    DateTime searchByDate = DateTime.Parse(userDateinput);

                                    var dateResult = context.Posts
                                                            .Where(p => p.DatePublished.Date == searchByDate.Date);

                                    if (dateResult.Any())
                                    {
                                        foreach (var post2 in dateResult)
                                        {
                                            Console.WriteLine($"Post ID: {post2.Id}\nDate published: {post2.DatePublished}\nTitle: {post2.Title}\nContent:{post2.Body}");
                                        }
                                    }
                                    else
                                    {
                                        Console.WriteLine("No results found!");
                                    }
                                }
                                catch (FormatException)
                                {
                                    Console.WriteLine("Invalid date format. Please use the format like 7/7/2025.");
                                }
                                break;
                            case 2:
                                Console.Write("Enter the Title you want to search by: ");
                                string searchByTitle = Console.ReadLine();
                                var titleResult = context.Posts.Where(p => p.Title == searchByTitle);
                                if (titleResult.Any())
                                {
                                    foreach (var post2 in titleResult)
                                    {
                                        Console.WriteLine($"Post ID: {post2.Id}\nDate published: {post2.DatePublished}\nTitle: {post2.Title}\nContent:{post2.Body}");
                                    }
                                }
                                else Console.WriteLine("No results found!");
                                break;
                            default:
                                Console.WriteLine("The choice you entered is incorrect!");
                                break;
                        }
                    }
                    break;
                default:
                    Console.WriteLine("The number you entered is incorrect! please try again.");
                    break;
            }//end switch
            Console.Write("1) List all Users \n2) List all posts \n3) Create new account \n4) Add new Post \n5) Edit account details  \n6) Edit Post \n7) Delete Post \n8) Delete account \n9) Search account by filter\n10) Search Post by filter\nEnter the number of the option you want OR enter -1 to stop: ");
            choise = Convert.ToInt32(Console.ReadLine());
        }
        Console.WriteLine("Thank you! Goodbye.");
    }//end Main()
}//end class Program
