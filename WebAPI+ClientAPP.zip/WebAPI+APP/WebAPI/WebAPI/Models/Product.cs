using System.ComponentModel.DataAnnotations;


public class Product
{
    public int Id { get; set; }
    [Required]
    [MinLength(3)]
    public required string Name { get; set; }
    [Required]
    [Range(10, 10000, ErrorMessage = "Price must be between 10 and 10000 only!")]
    public decimal Price { get; set; }
}//end class 
