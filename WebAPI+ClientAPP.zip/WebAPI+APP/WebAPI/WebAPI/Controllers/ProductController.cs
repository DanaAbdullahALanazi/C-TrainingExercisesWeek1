using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace WebAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ProductController : ControllerBase
    {
        private readonly DataContext dataContext;

        public ProductController(DataContext dataContext)
        {
            this.dataContext = dataContext;
        }//end constructor

        /*This method says: 
        “I promise to return a list of Product items,
         but I’m going to do it asynchronously, so please await my result.”*/

        [HttpGet]
        public async Task<IEnumerable<Product>> GetProductsAsync()
        {
            return await dataContext.Products.ToListAsync(); //1st API Endpoint
        }

        /*This method says:
        “When someone sends me a product in a POST request, I’ll take it,
         prepare it to be saved in the database,
         then actually save it. And finally, I’ll respond with OK (ActionResult)
         to confirm everything went fine.”*/

        [HttpPost]
        public async Task<ActionResult> AddProductsAsync(Product product)
        {
            await dataContext.Products.AddAsync(product);
            await dataContext.SaveChangesAsync();
            return Ok();

        }

        /*This method says:
        “When someone sends me a GET request asking for a product by its ID,
         I'll search the Products table in the database for that exact ID.
         If I don't find it, I'll say: 'Sorry, that product doesn't exist' (404).
         If I do find it, I'll send back the product's data.”
        */
        [HttpGet("id")]
        public async Task<ActionResult> GetProductByIdAsync(int Id)
        {
            Product? product = await dataContext.Products.FindAsync(Id);
            if (product == null)
            {
                return NotFound();
            }
            else return Ok(product);
        }

        /*
        */

        [HttpPut("id")]
        public async Task<ActionResult> UpdateProductByIdAsync(int Id, Product product)
        {
            if (Id == 0)
            {
                return BadRequest();
            }
            Product? targetProduct = await dataContext.Products.FindAsync(Id);
            if (targetProduct == null)
            {
                return NotFound();
            }
            targetProduct.Name = product.Name;
            targetProduct.Price = product.Price;
            await dataContext.SaveChangesAsync();
            return Ok();
        }

        [HttpDelete("id")]
        public async Task<ActionResult> DeleteProductByIdAsync(int Id)
        {
            Product? targetProduct = await dataContext.Products.FindAsync(Id);
            if (targetProduct == null)
            {
                return NotFound();
            }
            dataContext.Products.Remove(targetProduct);
            await dataContext.SaveChangesAsync();
            return Ok();
        }
    }
}

